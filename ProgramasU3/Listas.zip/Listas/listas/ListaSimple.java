package listas;

public abstract class ListaSimple implements Listas {
    protected Nodo primero;
    protected int tamaño;

    public ListaSimple() {
        this.primero = null;
        this.tamaño = 0;
    }

    public boolean estaVacia() {
        return this.primero == null;
    }

    public void insertar(Object obj) {
        Nodo nuevo = new Nodo(obj);
        if (this.estaVacia()) {
            this.primero = nuevo;
        } else {
            Nodo aux = this.primero;
            while (aux.getSiguiente() != null) {
                aux = aux.getSiguiente();
            }
            aux.setSiguiente(nuevo);
        }
        this.tamaño++;
    }

    public Object sacar() {
        Object obj = null;
        if (!this.estaVacia()) {
            obj = this.primero.getDato();
            this.primero = this.primero.getSiguiente();
            this.tamaño--;
        }
        return obj;
    }

    public void eliminar(int posicion) {
        if (posicion >= 0 && posicion < this.tamaño) {
            if (posicion == 0) {
                this.primero = this.primero.getSiguiente();
            } else {
                Nodo aux = this.primero;
                for (int i = 0; i < posicion - 1; i++) {
                    aux = aux.getSiguiente();
                }
                aux.setSiguiente(aux.getSiguiente().getSiguiente());
            }
            this.tamaño--;
        }
    }

    public void eliminar(Object obj) {
        if (!this.estaVacia()) {
            if (this.primero.getDato().equals(obj)) {
                this.primero = this.primero.getSiguiente();
                this.tamaño--;
            } else {
                Nodo aux = this.primero;
                while (aux.getSiguiente() != null && !aux.getSiguiente().getDato().equals(obj)) {
                    aux = aux.getSiguiente();
                }
                if (aux.getSiguiente() != null) {
                    aux.setSiguiente(aux.getSiguiente().getSiguiente());
                    this.tamaño--;
                }
            }
        }
    }

    public Nodo buscar(Object obj) {
        Nodo aux = this.primero;
        while (aux != null && !aux.getDato().equals(obj)) {
            aux = aux.getSiguiente();
        }
        return aux;
    }

    public int localizar(Object obj) {
        int posicion = -1;
        Nodo aux = this.primero;
        while (aux != null && !aux.getDato().equals(obj)) {
            aux = aux.getSiguiente();
            posicion++;
        }
        return posicion;
    }

    public void vaciar() {
        this.primero = null;
        this.tamaño = 0;
    }

    public void recorrer() {
        Nodo aux = this.primero;
        while (aux != null) {
            System.out.println(aux.getDato());
            aux = aux.getSiguiente();
        }
    }

    public int tamaño() {
        return this.tamaño;
    }

    public String toString() {
        String cadena = "";
        Nodo aux = this.primero;
        while (aux != null) {
            cadena += aux.getDato() + " ";
            aux = aux.getSiguiente();
        }
        return cadena;
    }
}