package listas;

public interface Listas {

    public abstract boolean estaVacia();

    public abstract void insertar(Object obj);

    public abstract Object sacar();

    public abstract void eliminar(int posicion);

    public abstract void eliminar(Object obj);

    public abstract Nodo buscar(Object obj);

    public abstract int localizar(Object obj);

    public abstract void vaciar();

    public abstract void recorrer();

    public abstract int tamaño();
}