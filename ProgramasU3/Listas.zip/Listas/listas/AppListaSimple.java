package listas;

// Import for JOptionPane
import javax.swing.JOptionPane;

public class AppListaSimple {
    public static void main(String[] args) {
        // Create a new ListaSimple and initialize it
        ListaSimple lista = new ListaSimple(){
        };
        // Create a menu
        int opcion = 0;
        String menu = "1. Insertar\n2. Sacar\n3. Eliminar\n4. Buscar\n5. Localizar\n6. Vaciar\n7. Recorrer\n8. Tamaño\n9. Salir";
        do {
            opcion = Integer.parseInt(JOptionPane.showInputDialog(null, menu, "Menú", JOptionPane.QUESTION_MESSAGE));
            switch (opcion) {
                case 1:
                    lista.insertar(JOptionPane.showInputDialog(null, "Ingrese el dato a insertar", "Insertar",
                            JOptionPane.QUESTION_MESSAGE));
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, "El dato sacado es: " + lista.sacar(), "Sacar",
                            JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 3:
                    lista.eliminar(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la posición a eliminar",
                            "Eliminar", JOptionPane.QUESTION_MESSAGE)));
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null,
                            "El dato buscado es: " + lista.buscar(JOptionPane.showInputDialog(null,
                                    "Ingrese el dato a buscar", "Buscar", JOptionPane.QUESTION_MESSAGE)),
                            "Buscar", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null,
                            "La posición del dato es: " + lista.localizar(JOptionPane.showInputDialog(null,
                                    "Ingrese el dato a localizar", "Localizar", JOptionPane.QUESTION_MESSAGE)),
                            "Localizar", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 6:
                    lista.vaciar();
                    break;
                case 7:
                    lista.recorrer();
                    break;
                case 8:
                    JOptionPane.showMessageDialog(null, "El tamaño de la lista es: " + lista.tamaño(), "Tamaño",
                            JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 9:
                    JOptionPane.showMessageDialog(null, "Hasta luego", "Salir", JOptionPane.INFORMATION_MESSAGE);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida", "Error", JOptionPane.ERROR_MESSAGE);
                    break;
            }
        } while (opcion != 9);
    }
}