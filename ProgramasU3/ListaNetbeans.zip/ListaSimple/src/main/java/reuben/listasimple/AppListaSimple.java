/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reuben.listasimple;

/**
 *
 * @author reuben
 */
// Import for JOptionPane
import javax.swing.JOptionPane;

public class AppListaSimple {
    public static void main(String[] args) {
        // Create a new ListaSimple and initialize it
        ListaSimple lista = new ListaSimple(){};
        // Create a menu
        int opcion = 0;
        String menu = "1. Insertar\n2. Sacar\n3. Eliminar por posicion\n4. Eliminar por objeto\n5. Buscar\n6. Localizar\n7. Vaciar\n8. Recorrer\n9. Tamaño\n10. Mostrar la lista\n11. Salir";
        do {
            try {
                opcion = Integer.parseInt(JOptionPane.showInputDialog(null, menu, "Menu de opciones", JOptionPane.QUESTION_MESSAGE));
                switch (opcion) {
                    case 1:
                        lista.insertar(JOptionPane.showInputDialog(null, "Ingrese el dato a insertar", "Insertar", JOptionPane.QUESTION_MESSAGE));
                        break;
                    case 2:
                        JOptionPane.showMessageDialog(null, "El dato sacado es: " + lista.sacar(), "Sacar", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    case 3:
                        lista.eliminarPos(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la posicion a eliminar", "Eliminar por posicion", JOptionPane.QUESTION_MESSAGE)));
                        break;
                    case 4:
                        lista.eliminarObj(JOptionPane.showInputDialog(null, "Ingrese el dato a eliminar", "Eliminar por objeto", JOptionPane.QUESTION_MESSAGE));
                        break;
                    case 5:
                        JOptionPane.showMessageDialog(null, "El dato buscado es: " + lista.buscar(JOptionPane.showInputDialog(null, "Ingrese el dato a buscar", "Buscar", JOptionPane.QUESTION_MESSAGE)), "Buscar", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    case 6:
                        if (lista.localizar(JOptionPane.showInputDialog(null, "Ingrese el dato a localizar", "Localizar", JOptionPane.QUESTION_MESSAGE)) == -1)
                            JOptionPane.showMessageDialog(null, "El dato no se encuentra en la lista", "Localizar", JOptionPane.INFORMATION_MESSAGE);
                        else
                            JOptionPane.showMessageDialog(null, "El dato se encuentra en la posicion: " + lista.localizar(JOptionPane.showInputDialog(null, "Ingrese el dato a localizar", "Localizar", JOptionPane.QUESTION_MESSAGE)), "Localizar", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    case 7:
                        lista.vaciar();
                        break;
                    case 8:
                        lista.recorrer();
                        break;
                    case 9:
                        JOptionPane.showMessageDialog(null, "El tamaño de la lista es: " + lista.tamaño(), "Tamaño", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    case 10:
                        JOptionPane.showMessageDialog(null, lista, "Lista", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    case 11:
                        JOptionPane.showMessageDialog(null, "Hasta luego", "Salir", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opcion no valida", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (opcion != 11);
    }
}