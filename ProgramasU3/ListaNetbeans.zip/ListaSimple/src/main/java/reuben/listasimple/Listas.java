/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reuben.listasimple;

/**
 *
 * @author reuben
 */

public interface Listas {

    public abstract boolean estaVacia();

    public abstract void insertar(Object obj);

    public abstract Object sacar();

    public abstract void eliminarPos(int posicion);

    public abstract void eliminarObj(Object obj);

    public abstract Object buscar(Object obj);

    public abstract int localizar(Object obj);

    public abstract void vaciar();

    public abstract void recorrer();

    public abstract int tamaño();
}