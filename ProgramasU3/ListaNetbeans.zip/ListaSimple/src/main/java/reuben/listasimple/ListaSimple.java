package reuben.listasimple;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author reuben
 */
// Import for JOptionPane
import javax.swing.JOptionPane;

public abstract class ListaSimple implements Listas {
    // Atributos
    protected Nodo primero;
    protected int tamaño;

    // Constructor
    public ListaSimple() {
        this.primero = null;
        this.tamaño = 0;
    }

    // Metodo de verificar si la lista esta vacia
    public boolean estaVacia() {
        return this.primero == null;
    }

    // Metodo de insertar un objeto en la lista
    public void insertar(Object obj) {
        Nodo nuevo = new Nodo(obj);
        if (this.estaVacia()) {
            this.primero = nuevo;
        } else {
            Nodo aux = this.primero;
            while (aux.getSiguiente() != null) {
                aux = aux.getSiguiente();
            }
            aux.setSiguiente(nuevo);
        }
        this.tamaño++;
    }

    // Metodo de sacar un objeto de la lista
    public Object sacar() {
        Object obj = null;
        if (!this.estaVacia()) {
            obj = this.primero.getDato();
            this.primero = this.primero.getSiguiente();
            this.tamaño--;
        }
        return obj;
    }

    // Metodo de eliminar un objeto de la lista mediante su posicion
    public void eliminarPos(int posicion) {
        if (posicion >= 0 && posicion < this.tamaño) {
            if (posicion == 0) {
                this.primero = this.primero.getSiguiente();
            } else {
                Nodo aux = this.primero;
                for (int i = 0; i < posicion - 1; i++) {
                    aux = aux.getSiguiente();
                }
                aux.setSiguiente(aux.getSiguiente().getSiguiente());
            }
            this.tamaño--;
        } else
            JOptionPane.showMessageDialog(null, "Posicion no valida, la lista tiene " + this.tamaño + " elementos");
    }

    // Metodo de eliminar un objeto de la lista mediante su dato
    public void eliminarObj(Object obj) {
        if (!this.estaVacia()) {
            if (this.primero.getDato().equals(obj)) {
                this.primero = this.primero.getSiguiente();
                this.tamaño--;
            } else {
                Nodo aux = this.primero;
                while (aux.getSiguiente() != null && aux.getSiguiente().getDato() != obj) {
                    aux = aux.getSiguiente();
                }
                if (aux.getSiguiente() != null) {
                    aux.setSiguiente(aux.getSiguiente().getSiguiente());
                    this.tamaño--;
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "La lista esta vacia");
        }
    }

    // Metodo de buscar un dato en la lista y devolverlo, si no se encuentra
    // devuelve null
    public Object buscar(Object obj) {
        Object dato = null;
        Nodo aux = this.primero;
        while (aux != null /* && aux.getDato() != obj */) {
            if (aux.getDato().equals(obj)) {
                return aux.getDato();
            }
            aux = aux.getSiguiente();
        }
        return dato;
    }

    // Metodo de localizar un dato en la lista y devolver su posicion, el atributo
    // posicion se inicializa en 0, si no se encuentra devuelve un mensaje diciendo
    // que no existe y si aux es null la posicion es -1
    public int localizar(Object obj) {
        int posicion = 0;
        Nodo aux = this.primero;
        while (aux != null /* && aux.getDato() != obj */) {
            if (aux.getDato().equals(obj)) {
                return posicion;
            }
            aux = aux.getSiguiente();
            posicion++;
        }
        if (aux == null) {
            posicion = -1;
        }
        return posicion;
    }

    // Metodo de vaciar la lista
    public void vaciar() {
        this.primero = null;
        this.tamaño = 0;
        JOptionPane.showMessageDialog(null, "Lista vaciada");
    }

    // Metodo de recorrer la lista y mostrar los datos
    public void recorrer() {
        Nodo aux = this.primero;
        while (aux != null) {
            JOptionPane.showMessageDialog(null, aux.getDato());
            aux = aux.getSiguiente();
        }
    }

    // Metodo de mostrar el tamaño de la lista
    public int tamaño() {
        return this.tamaño;
    }

    // toString
    public String toString() {
        String cadena = "";
        Nodo aux = this.primero;
        while (aux != null) {
            cadena += aux.getDato() + " ";
            aux = aux.getSiguiente();
        }
        return cadena;
    }
}